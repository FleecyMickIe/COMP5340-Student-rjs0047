//
//  ContentView.swift
//  practiceApp
//
//  Created by Ryan Smith on 10/22/26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationStack {
            
            List{
                
                Section {
                    VStack(alignment: .leading, spacing: 8) {
                        Image(systemName: "cup.and.saucer.fill")
                            .font(.largeTitle)
                            .foregroundStyle(.brown)

                        Text("Class Action Coffee")
                            .font(.title2)
                            .bold()

                        Text("Make your case for another cup.")
                            .font(.subheadline)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 8)
                }

                Section("Menu") {
                    ListItem(
                        iconName: "cup.and.saucer.fill",
                        itemName: "Brewed Coffee",
                        price: 3
                    )

                    ListItem(
                        iconName: "cup.and.saucer.fill",
                        itemName: "Latte",
                        price: 5
                    )

                    ListItem(
                        iconName: "leaf.fill",
                        itemName: "Tea",
                        price: 3
                    )

                    ListItem(
                        iconName: "birthday.cake.fill",
                        itemName: "Muffin",
                        price: 4
                    )
                }
                Section{
                  ActionItem()
                    
                }
                
                Section{
                    PickerItem()
                }
                
                Section{
                    ConfirmItem()
                }
                
                
            }
            .listStyle(GroupedListStyle())
            .navigationTitle(Text("Order"))
            
        }
    }
}
struct ListItem: View {
    var iconName: String = "cup.and.saucer.fill"
    var itemName: String
    var price: Int

    var body: some View {
        HStack {
            Image(systemName: iconName)
                .imageScale(.large)

            Text(itemName)

            Spacer()

            Text("$\(price)")
        }
        .foregroundStyle(Color.theme)
        .padding()
    }
}

struct ActionItem : View {
    
    @State var counter : Int = 0
    var body: some View {
        HStack {
            Image(systemName: "plus")
                .imageScale(.large)
                .onTapGesture {
                    
                    self.counter += 1
                }
            
            Spacer()
            Text("\(counter)")
        }
    }
}

struct PickerItem : View {
    
    @State var flag : Bool = false
    @State var tip: Int = 0
            var tipOptions: [Int] = [10, 15, 20, 25]
    var body: some View {
        VStack{
            Toggle("Add a tip?", isOn: $flag)
            
            if flag {
                Picker("Tip Percentage", selection: $tip) {
                    ForEach(tipOptions, id: \.self) { option in Text("\(option)")}
                }
            }
        }.pickerStyle(SegmentedPickerStyle())
        .padding()
        
    }
}


struct ConfirmItem : View {
    
    @State var present : Bool = false
    var body: some View {
        
        Button("Confirm Order") {
            present.toggle()
        }
        .sheet(isPresented: $present, content: { SecondView(present:$present)
        })
    }
}

struct SecondView: View {
    @Binding var present: Bool
    var body: some View {
        VStack{
            Text("Order Confirmed")
            Button("Dismiss") {
                present.toggle()
            }
        }
    }
}

#Preview {
    ContentView()
        .preferredColorScheme(.light)
}

#Preview {
    ContentView()
        .preferredColorScheme(.dark)
}
